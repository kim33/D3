# CS4460_Project

Project Members: 
David Gil, JiSu Kim, Kyuri Im, Yeon Jae Cho

The Goal:
The goal of the project is to help users easily analyze the large livestock and poultry consumption data provided by the U.S Department of Agriculture. Various users, such as retailers and farmers, frequently access this data to help them make good business decisions. The team wanted to provide these users with a better tool that will allow them to spend more time analyzing, rather than processing, the huge list of data that range from 1909 to 2014. The visualization not only shows the general trend of per capita availability of different types of meat, but also allows users to answer more specific questions regarding different subcomponents of the data. The team aimed to make the visualization simple and flexible that can cater to the wide range of users who will want to process this data. 
