

window.onload = start;


function start() {

    // This is for the radio button transitions and animations
    var FormStuff = {

        init: function() {
            this.applyConditionalRequired();
            this.bindUIActions();
        },

        bindUIActions: function() {
            $("input[type='radio'], input[type='checkbox']").on("change", this.applyConditionalRequired);
        },

        applyConditionalRequired: function() {

            $(".require-if-active").each(function() {
                var el = $(this);
                if ($(el.data("require-pair")).is(":checked")) {
                    el.prop("required", true);
                } else {
                    el.prop("required", false);
                }
            });

        }

    };


    /*|||||||||||||||||||
     ||     Variables   ||
     |||||||||||||||||||*/

    //var graph = document.getElementById("graph");
    var width = window.innerWidth;
    var height = window.innerHeight;
    var body = d3.select(document.getElementById("body"));
    var info = d3.select(document.getElementById("info"));
    var tools = d3.select(document.getElementById("toolbar"));

    //
    // var generateButton = d3.select(document.getElementById("generate"));
    var sampleData = "data/Carcass.csv";
    var datainput = d3.select(document.getElementById("dataRadio"));
    var graphinput = d3.select(document.getElementById("graphRadio"));

    var pie = d3.select(document.getElementById("pie"));
    var pie_info = d3.select(document.getElementById("pie_info"));
    var bar_info = d3.select(document.getElementById("bar_info"));
    var colors = ["#660000", "#ff0000", "#ff9966", "#ff4d88", "#6666ff", "#e6e6ff"];
    var svg = body.append('svg')
        .attr("height", 0);
    var svg2 = body.append('svg')
        .attr("height", 0);
    var animals;
    var before = [];
    var first = true;
    var graphSelect = "line";
    var dataSelect = "carcass"



    // d3.selectAll("input")
    //     .data([carcass, boneless], function(d) { return d ? d.name : this.value; })
    //     .on("change", dataChange);
    //
    // var timeout2 = d3.timeout(function() {
    //     d3.select("input[value=\"square\"]")
    //         .property("checked", true)
    //         .dispatch("change");
    // }, 2000);

    // function dataChange() {
    //
    // }



    //
    // function graphChange() {
    //     var graphChange = graphinput.value;
    //     if(graphChange == "line"){
    //         graphSelect = "line"
    //         GenerateGraph()
    //     }else{
    //         graphSelect = "stackedbar"
    //         GenerateGraph()
    //     }
    // }

    if(first == true){
        first = false
        document.getElementById('nav').style.position="absolute"
        GenerateGraph()
    }



    var g1 = document.getElementById('line?')
    var g2 = document.getElementById('bar?')

    g1.onclick = GenerateGraph
    g2.onclick = GenerateGraph


    var u1 = document.getElementById('lock?')
    var u2 = document.getElementById('unlock?')
    u1.onclick = lock
    // document.getElementById('nav').style.position = "static";
    u2.onclick = lock
    // document.getElementById('nav').style.position = "fixed";

    function lock() {
        if(u1.checked){
            document.getElementById('nav').style.position="absolute"
        }else {
            document.getElementById('nav').style.position="fixed"

        }
    }
    function GenerateGraph() {

        console.log(before)
        if (before.length != 0) {
            if (document.getElementById('line?').checked) {
                if (before[before.length - 1] == "2") {
                    d3.selectAll(".break").remove();
                    d3.select("tooltip").remove();
                    d3.select(".bargraph").transition().duration(1000).style("opacity", 0);
                    setTimeout(function () {
                        d3.select('.bargraph').remove();
                        draw()
                    }, 2000);

                } else {draw()}

            } else {
                if (before[before.length - 1] == "1") {
                    d3.select(".myPie").remove();
                    d3.selectAll(".pie_info2").remove();

                    d3.select(".linegraph").transition().duration(1000).style("opacity", 0);
                    setTimeout(function () {
                        d3.select('linegraph').remove();
                        draw()
                    }, 2000);

                }
                else {
                    d3.selectAll(".break").remove();
                    d3.select("tooltip").remove();
                    d3.select(".bargraph").transition().duration(1000).style("opacity", 0);
                    setTimeout(function () {
                        d3.select('.bargraph').remove();
                        draw()
                    }, 2000);

                }
            }
        } else {
            draw()
        }

        function draw() {

            if (document.getElementById('line?').checked) {
                before.push("1")


                document.getElementById("toolbar").innerHTML = "";
                // document.getElementById('dataSelect').value = "data/Carcass.csv";

                /*
                 *Creates Graph Area
                 */

                d3.select('.linegraph').remove();
                d3.select('.bargraph').remove();

                svg = body.append('svg');
                svg.attr("width", document.getElementById("body").scrollWidth - 6)
                    .attr("height", (document.getElementById("body").scrollWidth * .4))
                    .attr("class", "linegraph")
                    .attr("id", "linegraph")


                //Margins and sizes of widths and heightsmargin = {top: 20, right: 20, bottom: 110, left: 40},
                var margin = {top: 20, right: 20, bottom: 110, left: 40},
                    margin2 = {top: 395, right: 20, bottom: 30, left: 40},
                    width = +svg.attr("width") - margin.left - margin.right,
                    height = +svg.attr("height") - margin.top - margin.bottom,
                    height2 = +svg.attr("height") - margin2.top - margin2.bottom;


                //

                //time parser and axis scales
                var parseTime = d3.timeParse("%Y");
                var formatTime = d3.timeFormat("%Y");
                var formatNum = d3.format(",.2f");

                var z = d3.scaleOrdinal(colors);

                var x = d3.scaleTime().range([0, width]),
                    x2 = d3.scaleTime().range([0, width]),
                    y = d3.scaleLinear().range([height, 0]),
                    y2 = d3.scaleLinear().range([height2, 0]);

                var xAxis = d3.axisBottom(x),
                    xAxis2 = d3.axisBottom(x2),
                    yAxis = d3.axisLeft(y);


                var brush = d3.brushX()
                    .extent([[0, 0], [width, height2]])
                    .on("brush end", brushed);

                var zoom = d3.zoom()
                    .scaleExtent([1, Infinity])
                    .translateExtent([[0, 0], [width, height]])
                    .extent([[0, 0], [width, height]])
                    .on("zoom", zoomed);

                var focus = svg.append("g")
                    .attr("class", "focus")
                    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

                var context = svg.append("g")
                    .attr("class", "context")
                    .attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");

                var pieGraphSVG = pie.append("svg")
                    .attr('width', '140')
                    .attr('height', '140')
                    .attr("id", "myPie")
                    .attr("class", "myPie")
                    .attr("dy", "0.5em");



                // d3.select(document.getElementsByClassName('.dataRadio'))
                //     .on("click", GenerateChart)

                var d1 = document.getElementById('carc?')
                var d2 = document.getElementById('bone?')

                d1.onclick = GenerateChart
                d2.onclick = GenerateChart


                //line generator for line graph
                var line = d3.line()
                    .curve(d3.curveBasis)
                    .x(function (d) {
                        return x(d.Year);
                    })
                    .y(function (d) {
                        return y(d.avail);
                    });

                // data select parser using bisect
                var bisectDate = d3.bisector(function (d) {
                    return d;
                }).left;
                var formatValue = d3.format(",.2f");

                var line2 = d3.line()
                    .curve(d3.curveBasis)
                    .x(function (d) {
                        return x2(d.Year);
                    })
                    .y(function (d) {
                        return y2(d.avail);
                    });


                var rawdata = d3.csv(sampleData, type, function (error, data) {
                    if (error) throw error;
                    //sets up data
                    animals = data.columns.slice(1).map(function (id) {
                        return {
                            id: id,
                            values: data.map(function (d) {
                                return {Year: d.Year, avail: d[id]};
                            })
                        };
                    });

                    /*
                     Sets up domains declared earlier
                     */
                    x.domain(d3.extent(data, function (d) {
                        return d.Year;
                    }));
                    y.domain([
                        d3.min(animals, function (c) {
                            return d3.min(c.values, function (d) {
                                return d.avail;
                            });
                        }),
                        d3.max(animals, function (c) {
                            return d3.max(c.values, function (d) {
                                return d.avail;
                            });
                        })
                    ]);
                    z.domain(animals.map(function (c) {
                        return c.id;
                    }));
                    x2.domain(x.domain());
                    y2.domain(y.domain());

                    focus.selectAll('.line')
                        .data(animals)
                        .enter()
                        .append("path")
                        .attr("class", "line")
                        .attr('fill', 'none')
                        .attr("stroke", function (d) {
                            return z(d.id);
                        })
                        .attr('d', function (d) {
                            return line(d.values);
                        })
                        .attr("id", function (d) {
                            return "path" + d.id;
                        })
                        .on('mouseover', function (d) {
                            console.log('lol');
                        });
                    ;

                    focus.append("g")
                        .attr("class", "axis axis--x")
                        .attr("transform", "translate(0," + height + ")")
                        .call(xAxis)
                        .append("text")
                        .attr("dy", "5em")
                        .style('fill', 'white')
                        .style("stroke", "white")
                        .attr("font-weight", "bold")
                        .attr("text-anchor", "start")
                        .attr("dx", "60em")

                    focus.append("text")
                        .attr("text-anchor", "middle")
                        .attr("transform", "translate(" + (width / 2) + "," + (height + 50) + ")")
                        .text("Year")
                        .style("fill", "white");


                    focus.append("g")
                        .attr("class", "axis axis--y")
                        .call(yAxis)
                        .append("text")
                        .attr("dy", "-0.5em")
                        .style("fill", "white")
                        .attr("font-weight", "bold")
                        .attr("text-anchor", "start")
                        .text("lbs");

                    d3.selectAll(".domain")
                        .style('stroke', 'none')

                    d3.selectAll(".tick")
                        .style("stroke", "#fff")
                        .style("fill", "#fff")


                    svg.append("rect")
                        .attr("class", "zoom")
                        .attr("width", width)
                        .attr("height", height)
                        .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
                        .attr('opacity', 0)
                        .call(zoom)
                        .on("mousemove", mousemove);


                    /*
                     Sets up and fills in the legend
                     */
                    var legend = tools.append('svg')
                        .attr('height', '100')
                        .attr('width', '400')
                        .attr('class', 'myTools');


                    legend.append('g').selectAll('text')
                        .data(animals)
                        .enter()
                        .append('text')
                        .text(function (d) {
                            return d.id;
                        })
                        .attr("transform", function (d, i) {
                            if (i < 3) {
                                return "translate(80," + (((i + 1) * 30) - 16) + ")";
                            } else {
                                return "translate(150," + (((i - 2) * 30) - 16) + ")";
                            }
                        }
                        )
                        .attr("class", "legend")
                        .style('fill', '#fff');

                    legend.append('g').selectAll('rect')
                        .data(animals)
                        .enter()
                        .append('rect')
                        .attr('id', function (d) {
                            return "legend" + d.id;
                        })
                        .attr('width', 15)
                        .attr('height', 15)
                        .attr("transform", function (d, i) {
                            if (i < 3) {
                                return "translate(60," + i * 30 + ")";
                            } else {
                                return "translate(130," + (i - 3) * 30 + ")";
                            }
                        })
                        .attr('fill', function (d) {
                            return z(d.id);
                        })
                        .on('click', function (d, i) {
                            console.log(this);
                            var active = this.active ? false : true,
                                newOpacity = active ? 0 : 1;
                            d3.select('#legend' + d.id).transition().duration(100).style('opacity', newOpacity + 0.2);
                            d3.select("#path" + d.id).transition().duration(100).style('opacity', newOpacity);
                            this.active = active;
                        });
                    //starting dummy values
                    //will get replaced when user hovers over graph
                    var avails = [1, 1, 2, 1, 1, 1];

                    //PieSetup, arc, arcs, and path
                    //creates pie graph
                    var pieSetup = d3.pie()(avails);
                    console.log(animals);

                    var arc = d3.arc(pieSetup)
                        .innerRadius(0)
                        .outerRadius(60);

                    var arcs = pieGraphSVG.selectAll('g.slice')
                        .data(pieSetup)
                        .enter()
                        .append('g')
                        .attr('class', 'slice')
                        .append('path')
                        .attr('class', 'slice')
                        .attr("transform", "translate(70,70)");


                    var path = arcs
                        .attr('fill', function (d, i) {
                            console.log(i);
                            return z(animals[i].id);
                        })
                        .attr('d', arc)
                        .attr('opacity', '0');


                    //Hovering over graph function
                    //Updates pie graph on move
                    function mousemove() {
                        d3.selectAll(".pie_info2").remove();
                        var Year;
                        var percentages;

                        var formatNum2 = d3.format(".1f")

                        var x0 = x.invert(d3.mouse(this)[0]),
                            i = bisectDate(animals, x0, 1),
                            d0 = animals[i - 1],
                            d1 = animals[i],
                            d = x0 - d0.Year > d1.Year - x0 ? d1 : d0;
                        var hoverYear = formatTime(x0);

                        animals.forEach(function (d, i) {
                            Year = hoverYear - 1909
                            avails[i] = d.values[Year].avail;

                        });
                        var arc2 = d3.arc(d3.pie()(avails))
                            .innerRadius(0)
                            .outerRadius(60);
                        d3.selectAll('path.slice').data(d3.pie()(avails))
                            .transition().duration(200)
                            .attr('opacity', 1)
                            .attr('d', arc2);
                        console.log(avails);

                        var total = 0;

                        for (i = 0; i < avails.length; i++) {
                            total = total + avails[i];
                        }

                        var info = pie.append("div")
                            .attr("class", "pie_info2")
                            .text(hoverYear)
                            .style('fill', 'cornsilk')
                        pie.append("div")
                            .attr("class", "pie_info2")
                            .append("text")
                            .text("Total: " + formatNum(total) + "lbs")


                        var info2 = pie_info.append("div")
                            .attr("class", "pie_info2")

                            .html("<h2>Pie Legend</h2>");

                        var info3 = pie_info.append("div")
                            .attr("class", "pie_info2")
                            .html("<p> <span class='beefcol'> Beef: </span>" + formatNum2(avails[0]) + "lbs, " + formatNum(avails[0] / total * 100) + "%" + "<br>"
                                + "<span class='lambcol'>Lamb: </span>" + formatNum2(avails[1]) + "lbs, " + formatNum(avails[1] / total * 100) + "%" + "<br>"
                                + "<span class='vealcol'>Veal: </span>" + formatNum2(avails[2]) + "lbs, " + formatNum(avails[2] / total * 100) + "%" + "<br>"
                                + "<span class='porkcol'>Pork: </span>" + formatNum2(avails[3]) + "lbs, " + formatNum(avails[3] / total * 100) + "%" + "<br>"
                                + "<span class='turkeycol'>Turkey: </span>" + formatNum2(avails[4]) + "lbs, " + formatNum(avails[4] / total * 100) + "%" + "<br>"
                                + "<span class='chickencol'>Chicken: </span>" + formatNum2(avails[5]) + "lbs, " + formatNum(avails[5] / total * 100) + "%" + "<br>" + "<\p>")

                    }
                });

                /*
                 parses the data
                 */
                function type(d, _, columns) {
                    d.Year = parseTime(d.Year);
                    for (var i = 1, n = columns.length, c; i < n; ++i) d[c = columns[i]] = +d[c];
                    return d;
                }


                function GenerateChart() {

                    var data;

                    if (document.getElementById('carc?').checked) {
                        data = document.getElementById('carc?').value;
                    } else{
                        data = document.getElementById('bone?').value;
                    }

                    console.log(data);

                    var animal = document.getElementById('lines');
                    var newline = d3.line()
                        .curve(d3.curveBasis)
                        .x(function (d) {
                            return x(d.Year);
                        })
                        .y(function (d) {
                            return y(d.avail);
                        });


                    var rawdata = d3.csv(data, type, function (error, data) {

                        if (error) throw error;
                        //sets up data
                        animals = data.columns.slice(1).map(function (id) {
                            return {
                                id: id,
                                values: data.map(function (d) {
                                    return {Year: d.Year, avail: d[id]};
                                })
                            };
                        });


                        d3.selectAll('.contextLine')
                            .data(animals)
                            .transition()
                            .duration(400)
                            .attr("d", function (d) {
                                return line2(d.values)
                            });

                        d3.selectAll('.line')
                            .data(animals)
                            .transition()
                            .duration(400)
                            .attr("d", function (d) {
                                return line(d.values)
                            })

                    });
                }

                function brushed() {
                    if (d3.event.sourceEvent && d3.event.sourceEvent.type === "zoom") return; // ignore brush-by-zoom
                    var s = d3.event.selection || x2.range();
                    x.domain(s.map(x2.invert, x2));
                    focus.selectAll(".line").attr("d", function (d) {
                        return line(d.values);
                    });
                    focus.select(".axis--x").call(xAxis);
                    svg.select(".zoom").call(zoom.transform, d3.zoomIdentity
                        .scale(width / (s[1] - s[0]))
                        .translate(-s[0], 0));
                    d3.selectAll(".domain")
                        .style('stroke', 'none')

                    d3.selectAll(".tick")
                        .style("stroke", "#fff")
                        .style("fill", "#fff")
                }

                function zoomed() {
                    if (d3.event.sourceEvent && d3.event.sourceEvent.type === "brush") return; // ignore zoom-by-brush
                    var t = d3.event.transform;
                    x.domain(t.rescaleX(x2).domain());
                    focus.selectAll(".line").attr("d", function (d) {
                        return line(d.values);
                    });
                    focus.select(".axis--x").call(xAxis);
                    context.select(".brush").call(brush.move, x.range().map(t.invertX, t));
                    d3.selectAll(".domain")
                        .style('stroke', 'none')

                    d3.selectAll(".tick")
                        .style("stroke", "#fff")
                        .style("fill", "#fff")
                }

            }
            else {

                before.push("2")

                // document.getElementById("body").innerHTML = "";
                document.getElementById("toolbar").innerHTML = "";

                d3.select('.linegraph').remove();
                d3.select('.bargraph').remove();
                svg2 = body.append('svg');
                svg2.attr("width", document.getElementById("body").scrollWidth - 6)
                    .attr("height", (document.getElementById("body").scrollWidth * .4))
                    .attr("class", "bargraph")
                    .attr("id", "bargraph")


                margin = {top: 20, right: 20, bottom: 100, left: 40};
                width = +svg2.attr("width") - margin.left - margin.right;
                height = +svg2.attr("height") - margin.top - margin.bottom;

                datainput
                    .on("change", GenerateGraph);


                var g = svg2.append("g");
                g.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

                g.append("text")
                    .attr("text-anchor", "middle")
                    .attr("transform", "translate(" + (width / 2) + "," + (height + 50) + ")")
                    .text("Year")
                    .style("fill", "white");

                var xB = d3.scaleBand()
                    .rangeRound([0, width])
                    .paddingInner(0.05)
                    .align(0.1);

                var yB = d3.scaleLinear()
                    .rangeRound([height, 0]);

                var zB = d3.scaleOrdinal()
                    .range(colors);


                var tooltip = body.append("div")
                    .attr("class", "tooltip")
                    .style("opacity", 0);

                var formatNum = d3.format(",.2f");

                var dataNow

                if (document.getElementById('carc?').checked) {
                    dataNow = document.getElementById('carc?').value;
                } else{
                    dataNow = document.getElementById('bone?').value;
                }

                d3.csv(dataNow, function (d, i, columns) {
                    for (i = 1, t = 0; i < columns.length; ++i) {
                        t += d[columns[i]] = +d[columns[i]];
                    }

                    d.total = t;


                    return d;
                }, function (error, data) {
                    if (error) throw error;

                    var keys = data.columns.slice(1);

                    //data.sort(function(a, b) { return b.total - a.total; });

                    xB.domain(data.map(function (d) {
                        return d.Year = +d.Year;
                        return d.Year;
                    }));
                    yB.domain([0, d3.max(data, function (d) {
                        return d.total;
                    })]).nice();
                    zB.domain(keys);


                    g.append("g")
                        .selectAll("g")
                        .data(d3.stack().keys(keys)(data))
                        .enter().append("g")
                        .attr("class", "stacked")
                        .attr("id", function (d) {
                            return d.key;
                        })
                        .attr("fill", function (d) {
                            return zB(d.key);
                        })

                        .selectAll("rect")
                        .data(function (d) {
                            return d;
                        })
                        .enter().append("rect")
                        .attr("x", function (d) {
                            return xB(d.data.Year);
                        })
                        .attr("y", function (d) {
                            return yB(d[1]);
                        })
                        .attr("height", function (d) {
                            return yB(d[0]) - yB(d[1]);
                        })
                        .attr("width", xB.bandwidth())

                        .on("mouseover", function (d) {
                            tooltip.transition()
                                .duration(200)
                                .style("opacity", .75);

                            tooltip.html(
                                "<strong>" + formatNum(d[1] - d[0]) + "</strong>" + "lbs")
                                .style("left", (d3.event.pageX + 5) + "px")
                                .style("top", (d3.event.pageY - 10) + "px");

                            bar_info.append("br")
                                .attr("class", "break")
                            bar_info.append("br")
                                .attr("class", "break")

                            var infoLabel0 = bar_info.append("div")
                                .attr("class", "bar_info0")
                                .attr("id", "bar_info0")
                                .text(d.data.Year)

                            var infoLabel1 = bar_info.append("div")
                                .attr("class", "bar_info1")
                                .attr("id", "bar_info1")
                                .text("Total: " + formatNum(d.data.total) + "lbs").attr("dy", "1em")
                                .style("fill", "cornsilk");


                        })
                        .on("mouseout", function (d) {

                            tooltip.transition()
                                .duration(500)
                                .style("opacity", 0);
                            d3.select("#bar_info0").remove();
                            d3.select("#bar_info1").remove();
                            d3.selectAll(".break").remove();

                        });


                    g.append("g")
                        .attr("class", "axis")
                        .attr("transform", "translate(0," + height + ")")
                        .call(d3.axisBottom(xB))
                        .selectAll("text")
                        .attr("transform", "rotate(90)")
                        .attr("dy", "-.5em")
                        .attr("dx", ".7em")
                        .style("text-anchor", "start")

                    var dataName = dataNow;
                    dataName = dataName.split("/")
                    var dat = dataName[1]
                    dat = dat.split(".")
                    dat = dat[0]
                    g.append("g")
                        .attr("class", "axis")
                        .call(d3.axisLeft(yB).ticks(null, "s"))
                        .append("text")
                        .attr("x", 2)
                        .attr("y", yB(yB.ticks().pop()) + 0.5)
                        .attr("dy", "0.32em")
                        .attr("font-weight", "bold")
                        .attr("text-anchor", "start")
                        .text(dat + "(lbs)")
                        .style("fill", "#fff");


                    d3.selectAll(".tick")
                        .style("stroke", "#fff")
                        // .style("fill", "#fff")

                    var d1 = document.getElementById('carc?')
                    var d2 = document.getElementById('bone?')

                    d1.onclick = GenerateGraph
                    d2.onclick = GenerateGraph


                    var legend = tools.append('svg')
                        .attr('height', '100')
                        .attr('width', '400');


                    legend.append('g').selectAll('text')
                        .data(keys)
                        .enter()
                        .append('text')
                        .text(function (d) {
                            return d;
                        })
                        .attr("transform", function (d, i) {
                            if (i < 3) {
                                return "translate(80," + (((i + 1) * 30) - 16) + ")";
                            } else {
                                return "translate(150," + (((i - 2) * 30) - 16) + ")";
                            }
                        })
                        .attr("class", "legend")
                        .attr("fill", "#fff");
                    legend.append('g').selectAll('rect')
                        .data(keys)
                        .enter()
                        .append('rect')
                        .attr('id', function (d) {
                            return d + "leg";
                        })
                        .attr('width', 15)
                        .attr('height', 15)
                        .attr("transform", function (d, i) {
                            if (i < 3) {
                                return "translate(60," + i * 30 + ")";
                            } else {
                                return "translate(130," + (i - 3) * 30 + ")";
                            }
                        })
                        .attr('fill', zB)
                        .on('click', function (d, i) {
                            console.log(d);
                            var active = this.active ? false : true,
                                newOpacity = active ? 0 : 1;
                            highlightcol = active ? "#ffff33" : function (d) {
                                    return zB(d.key)
                                };
                            d3.select('#' + d + "leg").transition().duration(100).style('opacity', newOpacity + 0.2);
                            d3.selectAll("#" + d).transition().duration(100).style('fill', highlightcol).style('opacity', newOpacity)

                            this.active = active;
                        });

                });

            }
        }
    }
}
